<?php
function sueldo($n1,$n2)
{
	$r=$n1*$n2;
	return $r;
}
?>
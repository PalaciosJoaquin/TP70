<?php
include_once("pagina2.php");
$n1=$_POST['n1'];
$n2=$_POST['n2'];
$nombre=$_POST['nombre'];
$total=sueldo($n1,$n2);
echo('El sueldo total de '.$nombre.' es '.$total);
?>